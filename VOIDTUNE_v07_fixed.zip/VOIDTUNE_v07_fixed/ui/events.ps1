# VOIDTUNE - ui/events.ps1
# Copyright (C) 2026 @OTZPT - GPL v3
# All event handlers, data binding, timer

# ── DATA BINDING ──────────────────────────────────────────────────────────────
$script:TweakTabs = G 'TweakTabs'

$script:svcOC = New-Object 'System.Collections.ObjectModel.ObservableCollection[SI]'
foreach ($s in $script:SVCS_DATA) { $script:svcOC.Add($s) }
$sl = G 'SvcList'; if($sl){ $sl.ItemsSource = $script:svcOC }

$privCol = New-Object 'System.Collections.ObjectModel.ObservableCollection[TI]'
foreach ($t in $script:PRIVTWEAKS) { $privCol.Add($t) }
$pl = G 'PrivList'; if($pl){ $pl.ItemsSource = $privCol }

$appCol = New-Object 'System.Collections.ObjectModel.ObservableCollection[AI]'
foreach ($a in $script:APPS_DATA) { $appCol.Add($a) }
$al = G 'AppList'
if ($al) {
    $al.ItemsSource = $appCol
    $view = [System.Windows.Data.CollectionViewSource]::GetDefaultView($appCol)
    $view.GroupDescriptions.Clear()
    $view.GroupDescriptions.Add((New-Object System.Windows.Data.PropertyGroupDescription "Cat"))
    $view.SortDescriptions.Add((New-Object System.ComponentModel.SortDescription "Cat", "Ascending"))
    $view.SortDescriptions.Add((New-Object System.ComponentModel.SortDescription "Name", "Ascending"))
}

# App search bar
$appSearchBox = G 'AppSearch'
if ($appSearchBox) {
    $appSearchBox.Add_TextChanged({
        try {
            $q = (G 'AppSearch').Text.Trim().ToLower()
            $view = [System.Windows.Data.CollectionViewSource]::GetDefaultView((G 'AppList').ItemsSource)
            if ([string]::IsNullOrEmpty($q)) {
                $view.Filter = $null
            } else {
                $view.Filter = [Predicate[object]]{
                    param($item)
                    $item.Name.ToLower().Contains($q) -or $item.Cat.ToLower().Contains($q)
                }
            }
        } catch {}
    })
}
(G 'BtnAppSearchClear').Add_Click({
    try {
        $sb = G 'AppSearch'; if($sb){ $sb.Text = '' }
        $view = [System.Windows.Data.CollectionViewSource]::GetDefaultView((G 'AppList').ItemsSource)
        $view.Filter = $null
    } catch {}
})

if ($script:TweakTabs) { $script:TweakTabs.Add_SelectionChanged({ try { FilterTweaks } catch {} }) }
FilterTweaks

# ── NAVIGATION ────────────────────────────────────────────────────────────────
(G 'BtnDash').Add_Click({       try { ShowPage 'PgDash' }       catch {} })
(G 'BtnTweaks').Add_Click({     try { ShowPage 'PgTweaks' }     catch {} })
(G 'BtnApps').Add_Click({       try { ShowPage 'PgApps' }       catch {} })
(G 'BtnServices').Add_Click({   try { ShowPage 'PgServices' }   catch {} })
(G 'BtnStartup').Add_Click({    try { ShowPage 'PgStartup' }    catch {} })
(G 'BtnPrivacy').Add_Click({    try { ShowPage 'PgPrivacy' }    catch {} })
(G 'BtnDiag').Add_Click({       try { ShowPage 'PgDiag' }       catch {} })
(G 'BtnBench').Add_Click({      try { ShowPage 'PgBench' }      catch {} })
(G 'BtnSafety').Add_Click({     try { ShowPage 'PgSafety' }     catch {} })
(G 'BtnScript').Add_Click({     try { ShowPage 'PgScript' }     catch {} })
(G 'BtnProc').Add_Click({       try { ShowPage 'PgProc' }       catch {} })
(G 'BtnPersonalize').Add_Click({ try { ShowPage 'PgPersonalize' } catch {} })
(G 'BtnDrivers').Add_Click({    try { ShowPage 'PgDrivers' }    catch {} })
(G 'BtnGpuHealth').Add_Click({  try { ShowPage 'PgGpuHealth' }  catch {} })
(G 'BtnLatency').Add_Click({    try { ShowPage 'PgLatency' }    catch {} })

# ── SIDEBAR ACTIONS ───────────────────────────────────────────────────────────
(G 'BtnApplyAll').Add_Click({
    try {
        (G 'BtnApplyAll').IsEnabled = $false
        $script:Win.Dispatcher.BeginInvoke([action]{
            DoApply
            $b = G 'BtnApplyAll'; if($b){ $b.IsEnabled = $true }
        })
    } catch {}
})
(G 'BtnSafeMode').Add_Click({
    try {
        foreach ($t in $script:TWEAKS + $script:PRIVTWEAKS + $script:ARCH_TWEAKS) { $t.Sel = ($t.Badge -eq 'SAFE') }
        FilterTweaks
        AddLog "Safe mode: all SAFE tweaks selected." '#22C55E'
    } catch {}
})
(G 'BtnClearAll').Add_Click({
    try {
        foreach ($t in $script:TWEAKS + $script:PRIVTWEAKS + $script:ARCH_TWEAKS) { $t.Sel = $false }
        foreach ($a in $script:APPS_DATA) { $a.Sel = $false }
        FilterTweaks
        AddLog "Cleared all selections." '#3A3A3A'
    } catch {}
})

# ── DISABLE TWEAK (revert applied tweak) ──────────────────────────────────────
# Use AddHandler on TweakList to catch bubbled Button.Click from DataTemplate
$tl = G 'TweakList'
if ($tl) {
    $tl.AddHandler(
        [System.Windows.Controls.Button]::ClickEvent,
        [System.Windows.RoutedEventHandler]{
            param($s, $e)
            $btn = $e.OriginalSource
            if (-not ($btn -is [System.Windows.Controls.Button])) { return }
            if ($btn.Name -ne 'BtnDisableTweak') { return }
            $e.Handled = $true
            $id = $btn.Tag
            $all = $script:TWEAKS + $script:PRIVTWEAKS + $script:ARCH_TWEAKS
            $tw = $all | Where-Object { $_.Id -eq $id } | Select-Object -First 1
            if (-not $tw) { return }
            try {
                $confirm = [System.Windows.MessageBox]::Show(
                    "Disable tweak: $($tw.Name)?`n`nThis will run the revert command to undo this setting.",
                    "VOIDTUNE - Disable Tweak",
                    [System.Windows.MessageBoxButton]::YesNo,
                    [System.Windows.MessageBoxImage]::Question)
                if ($confirm -ne 'Yes') { return }
                if ([string]::IsNullOrEmpty($tw.RevertCmd)) {
                    AddLog "No revert command for $($tw.Name) -- mark as unapplied only." '#F59E0B'
                } else {
                    AddLog "Reverting: $($tw.Name)" '#F59E0B'
                    $r = Exec-Cmd $tw.RevertCmd
                    if ($r.OK) { AddLog "  Reverted OK" '#22C55E' }
                    else       { AddLog "  Revert failed: $($r.Out.Split("`n")[0])" '#E01818' }
                }
                $tw.Applied = $false
                $tw.Sel     = $false
                $script:applied = [math]::Max(0, $script:applied - 1)
                $da = G 'DashApplied'; if($da){ $da.Text = $script:applied }
                Save-TweakState
                FilterTweaks
            } catch { AddLog "Disable error: $($_.Exception.Message)" '#E01818' }
        }
    )
}
(G 'BtnLogClear').Add_Click({ try { $lo = G 'LogOut'; if($lo){ $lo.Text = '' } } catch {} })

# ── SERVICES ──────────────────────────────────────────────────────────────────
# ── SERVICES ──────────────────────────────────────────────────────────────────
# Gaming mode - disable non-essential services
(G 'BtnSvcGaming').Add_Click({
    try {
        $gaming = @('DiagTrack','dmwappushservice','SysMain','WSearch','XboxGip',
                    'XblAuthManager','XblGameSave','XboxNetApiSvc','MapsBroker',
                    'RetailDemo','WMPNetworkSvc','TabletInputService','Fax')
        AddLog "Applying GAMING profile..." '#22C55E'
        foreach ($svc in $gaming) {
            RunC "sc config $svc start= disabled" | Out-Null
            RunC "sc stop $svc" | Out-Null
        }
        AddLog "GAMING profile applied. $($gaming.Count) services disabled." '#22C55E'
        RefreshSvcs
    } catch { AddLog "Profile error: $($_.Exception.Message)" '#E01818' }
})

# Normal mode - restore safe defaults
(G 'BtnSvcNormal').Add_Click({
    try {
        $restore = @{
            'SysMain'='auto'; 'WSearch'='auto'; 'bthserv'='auto'
            'Spooler'='auto'; 'W32Time'='auto'
        }
        $disable = @('DiagTrack','dmwappushservice','XblGameSave','XboxNetApiSvc',
                     'TabletInputService','Fax','MapsBroker','RetailDemo','WMPNetworkSvc')
        AddLog "Applying NORMAL profile..." '#38BDF8'
        foreach ($kv in $restore.GetEnumerator()) {
            RunC "sc config $($kv.Key) start= $($kv.Value)" | Out-Null
            RunC "sc start $($kv.Key)" | Out-Null
        }
        foreach ($svc in $disable) {
            RunC "sc config $svc start= disabled" | Out-Null
            RunC "sc stop $svc" | Out-Null
        }
        AddLog "NORMAL profile applied." '#38BDF8'
        RefreshSvcs
    } catch { AddLog "Profile error: $($_.Exception.Message)" '#E01818' }
})

# Disable all - nuke everything in the list
(G 'BtnSvcDisableAll').Add_Click({
    try {
        $confirm = [System.Windows.MessageBox]::Show(
            "Disable ALL services in the list?`nThis will disable telemetry, Xbox, search, print spooler and more.`n`nA registry backup is recommended first.",
            "VOIDTUNE - Disable All Services",
            [System.Windows.MessageBoxButton]::YesNo,
            [System.Windows.MessageBoxImage]::Warning)
        if ($confirm -ne 'Yes') { return }
        AddLog "Disabling all listed services..." '#F59E0B'
        $count = 0
        foreach ($s in $script:SVCS_DATA) {
            RunC "sc config $($s.Name) start= disabled" | Out-Null
            RunC "sc stop $($s.Name)" | Out-Null
            $count++
        }
        AddLog "Disabled $count services." '#22C55E'
        RefreshSvcs
    } catch { AddLog "Disable all error: $($_.Exception.Message)" '#E01818' }
})

(G 'BtnSvcRefresh').Add_Click({ try { RefreshSvcs } catch {} })
(G 'SvcList').Add_PreviewMouseLeftButtonUp({
    param($s,$e)
    try {
        $el = $e.OriginalSource; $i = 0
        while ($el -and $el -isnot [System.Windows.Controls.Button] -and $i -lt 10) {
            try { $el = [System.Windows.Media.VisualTreeHelper]::GetParent($el) } catch { break }
            $i++
        }
        if ($el -and $el -is [System.Windows.Controls.Button] -and $el.Tag) {
            $svcName = $el.Tag
            # Dependency check before stopping
            $deps = $script:SVC_DEPS[$svcName]
            if ($el.Content -eq 'STOP' -and $deps -and $deps.Count -gt 0) {
                $depList = $deps -join ', '
                $confirm = [System.Windows.MessageBox]::Show(
                    "Stopping '$svcName' may affect: $depList`nContinue?",
                    "VOIDTUNE - Dependency Warning",
                    [System.Windows.MessageBoxButton]::YesNo,
                    [System.Windows.MessageBoxImage]::Warning)
                if ($confirm -ne 'Yes') { return }
            }
            if ($el.Content -eq 'STOP') { RunC "sc stop $svcName" | Out-Null }
            else                        { RunC "sc start $svcName" | Out-Null }
            Start-Sleep -Milliseconds 600
            RefreshSvcs
        }
    } catch {}
})

# ── STARTUP ───────────────────────────────────────────────────────────────────
(G 'BtnStartupRefresh').Add_Click({ try { RefreshStartup } catch {} })
(G 'StartupList').Add_PreviewMouseLeftButtonUp({
    param($s,$e)
    try {
        $el = $e.OriginalSource; $i = 0
        while ($el -and $el -isnot [System.Windows.Controls.Button] -and $i -lt 10) {
            try { $el = [System.Windows.Media.VisualTreeHelper]::GetParent($el) } catch { break }
            $i++
        }
        if ($el -and $el -is [System.Windows.Controls.Button] -and $el.Tag) {
            $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'
            if (!(Test-Path $k)) { New-Item $k -Force | Out-Null }
            Set-ItemProperty -Path $k -Name $el.Tag -Value ([byte[]](0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -EA SilentlyContinue
            AddLog "Disabled startup: $($el.Tag)" '#22C55E'
            RefreshStartup
        }
    } catch {}
})

# ── PROCESS MONITOR ───────────────────────────────────────────────────────────
(G 'BtnProcRefresh').Add_Click({ try { RefreshProc } catch {} })

(G 'BtnKillBloat').Add_Click({
    try {
        $confirm = [System.Windows.MessageBox]::Show(
            "Kill all known bloat processes?`n`nThis will close: OneDrive, Cortana, Widgets, Xbox Game Bar, Teams background, Adobe ARM, and other non-essential Microsoft/vendor processes.`n`nYour browser, games and apps will NOT be closed.",
            "VOIDTUNE - Kill Bloat",
            [System.Windows.MessageBoxButton]::YesNo,
            [System.Windows.MessageBoxImage]::Warning)
        if ($confirm -ne 'Yes') { return }
        AddLog "Killing bloat processes..." '#F59E0B'
        Kill-Bloat
    } catch {}
})
(G 'ProcList').Add_PreviewMouseLeftButtonUp({
    param($s,$e)
    try {
        $el = $e.OriginalSource; $i = 0
        while ($el -and $el -isnot [System.Windows.Controls.Button] -and $i -lt 10) {
            try { $el = [System.Windows.Media.VisualTreeHelper]::GetParent($el) } catch { break }
            $i++
        }
        if ($el -and $el -is [System.Windows.Controls.Button] -and $el.Tag) {
            $pid  = [int]$el.Tag
            $proc = Get-Process -Id $pid -EA SilentlyContinue
            $pname = if ($proc) { $proc.ProcessName } else { 'unknown' }
            $blocked = @('csrss','winlogon','lsass','smss','wininit','services','System','Idle','dwm','svchost')
            if ($blocked -contains $pname) {
                [System.Windows.MessageBox]::Show(
                    "Cannot kill '$pname' - critical Windows process.`nTerminating it would cause a BSOD.",
                    "VOIDTUNE - Protected Process",
                    [System.Windows.MessageBoxButton]::OK,
                    [System.Windows.MessageBoxImage]::Warning)
                return
            }
            if ([System.Windows.MessageBox]::Show("Kill process: $pname (PID $pid)?","VOIDTUNE",[System.Windows.MessageBoxButton]::YesNo) -eq 'Yes') {
                Stop-Process -Id $pid -Force -EA SilentlyContinue
                AddLog "Killed: $pname (PID $pid)" '#22C55E'
                Start-Sleep -Milliseconds 400
                RefreshProc
            }
        }
    } catch {}
})

# ── DASHBOARD & DIAG ─────────────────────────────────────────────────────────
(G 'BtnRefreshDash').Add_Click({ try { RefreshDash } catch {} })
(G 'BtnDiagRefresh').Add_Click({ try { RefreshDiag } catch {} })

# ── QUICK ACTIONS ─────────────────────────────────────────────────────────────
(G 'BtnQFlushDns').Add_Click({
    try {
        $r = RunC 'ipconfig /flushdns'
        $ql = G 'QuickActLog'; if($ql){ $ql.Text = if($r.OK){'DNS cache flushed.'}else{'DNS flush failed.'} }
        AddLog "Quick Action: Flush DNS — $(if($r.OK){'OK'}else{'FAIL'})" '#22C55E'
    } catch {}
})
(G 'BtnQClearTemp').Add_Click({
    try {
        RunC 'del /q /f /s "%TEMP%\*" 2>nul' | Out-Null
        $ql = G 'QuickActLog'; if($ql){ $ql.Text = "Temp files cleared." }
        AddLog "Quick Action: Clear Temp — OK" '#22C55E'
    } catch {}
})
(G 'BtnQRestartExp').Add_Click({
    try {
        RunC 'taskkill /f /im explorer.exe' | Out-Null
        Start-Sleep -Milliseconds 800
        Start-Process explorer.exe
        $ql = G 'QuickActLog'; if($ql){ $ql.Text = "Explorer restarted." }
        AddLog "Quick Action: Restart Explorer — OK" '#22C55E'
    } catch {}
})
(G 'BtnQRecycleBin').Add_Click({
    try {
        Clear-RecycleBin -Force -EA SilentlyContinue
        $ql = G 'QuickActLog'; if($ql){ $ql.Text = "Recycle Bin emptied." }
        AddLog "Quick Action: Empty Recycle Bin — OK" '#22C55E'
    } catch {}
})
(G 'BtnQDefrag').Add_Click({
    try {
        $ql = G 'QuickActLog'; if($ql){ $ql.Text = "Defrag started in background..." }
        Start-Process -FilePath 'defrag.exe' -ArgumentList 'C: /U /V' -WindowStyle Hidden
        AddLog "Quick Action: Defrag C: started" '#22C55E'
    } catch {}
})

# ── BACKUP & RESTORE ──────────────────────────────────────────────────────────
(G 'BtnBkRefresh').Add_Click({ try { RefreshBackups } catch {} })
(G 'BtnMkBackup').Add_Click({
    try { $n = MakeBackup 'manual'; AddLog "Backup created: $n" '#22C55E'; RefreshBackups }
    catch { AddLog "Backup error: $($_.Exception.Message)" '#E01818' }
})
(G 'BtnRestorePt').Add_Click({
    try {
        $r1 = RunC 'powershell -Command "Enable-ComputerRestore -Drive C:\"'
        $r2 = RunC 'powershell -Command "Checkpoint-Computer -Description ''VOIDTUNE Backup'' -RestorePointType MODIFY_SETTINGS"'
        if ($r2.OK) { AddLog "Windows restore point created." '#22C55E' }
        else        { AddLog "Restore point failed. Try: Control Panel > System Protection > Enable on C:" '#E01818' }
    } catch { AddLog "Restore point error: $($_.Exception.Message)" '#E01818' }
})
(G 'BackupList').Add_PreviewMouseLeftButtonUp({
    param($s,$e)
    try {
        $el = $e.OriginalSource; $i = 0
        while ($el -and $el -isnot [System.Windows.Controls.Button] -and $i -lt 10) {
            try { $el = [System.Windows.Media.VisualTreeHelper]::GetParent($el) } catch { break }
            $i++
        }
        if ($el -and $el -is [System.Windows.Controls.Button] -and $el.Tag) {
            $f = Join-Path $script:BACKUPS $el.Tag
            if ([System.Windows.MessageBox]::Show("Restore from $($el.Tag)?","VOIDTUNE",[System.Windows.MessageBoxButton]::YesNo) -eq 'Yes') {
                $r = RunC "reg import `"$f`""
                $rMsg = if($r.OK) { "Restored. Restart recommended." } else { "Restore failed: $($r.Out.Split("`n")[0])" }
                $rCol = if($r.OK) { "#22C55E" } else { "#E01818" }
                AddLog $rMsg $rCol
            }
        }
    } catch {}
})

# ── BENCHMARKS ────────────────────────────────────────────────────────────────
function UpdateBH {
    try { UI { $bh = G 'BenchHist'; if($bh){ $bh.Text = ($script:benchLog | Select-Object -Last 8) -join "`n" } } } catch {}
}
$script:allBenchBtns = @('BtnBDisk','BtnBDiskR','BtnBRam','BtnBCpu','BtnBNet','BtnBDns','BtnBRunAll')
function LockBench   { $script:benchRunning = $true;  foreach ($bn in $script:allBenchBtns) { $b = G $bn; if($b){ $b.IsEnabled = $false } } }
function UnlockBench { $script:benchRunning = $false; foreach ($bn in $script:allBenchBtns) { $b = G $bn; if($b){ $b.IsEnabled = $true  } } }

(G 'BtnBDisk').Add_Click({
    try {
        if ($script:benchRunning) { return }; LockBench
        $dv = G 'BDiskVal'; if($dv){ $dv.Text = '...' }
        try {
            $t = "$env:TEMP\zb.tmp"; $sw = [System.Diagnostics.Stopwatch]::StartNew()
            [System.IO.File]::WriteAllBytes($t,(New-Object byte[](52428800))); $sw.Stop()
            Remove-Item $t -Force -EA SilentlyContinue
            $v = [math]::Round(50/$sw.Elapsed.TotalSeconds)
            $dv = G 'BDiskVal'; if($dv){ $dv.Text = $v }
            $db = G 'BDiskBar'; if($db){ $db.Value = [math]::Min(100,$v/6) }
            $script:benchLog += "DISK WRITE: ${v} MB/s  $(Get-Date -f HH:mm)"; UpdateBH
        } catch { $dv = G 'BDiskVal'; if($dv){ $dv.Text = 'ERR' } }
        UnlockBench
    } catch { UnlockBench }
})
(G 'BtnBDiskR').Add_Click({
    try {
        if ($script:benchRunning) { return }; LockBench
        $rv = G 'BDiskRVal'; if($rv){ $rv.Text = '...' }
        try {
            $t = "$env:TEMP\zbr.tmp"; $data = New-Object byte[] 52428800
            [System.IO.File]::WriteAllBytes($t,$data)
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            [System.IO.File]::ReadAllBytes($t) | Out-Null; $sw.Stop()
            Remove-Item $t -Force -EA SilentlyContinue
            $v = [math]::Round(50/$sw.Elapsed.TotalSeconds)
            $rv = G 'BDiskRVal'; if($rv){ $rv.Text = $v }
            $rb = G 'BDiskRBar'; if($rb){ $rb.Value = [math]::Min(100,$v/6) }
            $script:benchLog += "DISK READ: ${v} MB/s  $(Get-Date -f HH:mm)"; UpdateBH
        } catch { $rv = G 'BDiskRVal'; if($rv){ $rv.Text = 'ERR' } }
        UnlockBench
    } catch { UnlockBench }
})
(G 'BtnBRam').Add_Click({
    try {
        if ($script:benchRunning) { return }; LockBench
        $rv = G 'BRamVal'; if($rv){ $rv.Text = '...' }
        try {
            $ms = New-Object System.IO.MemoryStream 134217728; $buf = New-Object byte[] 1048576
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            for ($i=0;$i -lt 128;$i++) { $ms.Write($buf,0,$buf.Length) }
            $sw.Stop(); $ms.Dispose()
            $v = [math]::Round(128/$sw.Elapsed.TotalSeconds)
            $rv = G 'BRamVal'; if($rv){ $rv.Text = $v }
            $rb = G 'BRamBar'; if($rb){ $rb.Value = [math]::Min(100,$v/100) }
            $script:benchLog += "RAM: ${v} MB/s  $(Get-Date -f HH:mm)"; UpdateBH
        } catch { $rv = G 'BRamVal'; if($rv){ $rv.Text = 'ERR' } }
        UnlockBench
    } catch { UnlockBench }
})
(G 'BtnBCpu').Add_Click({
    try {
        if ($script:benchRunning) { return }; LockBench
        $cv = G 'BCpuVal'; if($cv){ $cv.Text = '...' }
        try {
            $sw = [System.Diagnostics.Stopwatch]::StartNew(); $n=0
            for ($x=2;$x -lt 100000;$x++) {
                $p=$true; for ($y=2;$y -le [math]::Sqrt($x);$y++) { if($x%$y -eq 0){$p=$false;break} }
                if($p){$n++}
            }
            $sw.Stop(); $v=[math]::Round($n/$sw.Elapsed.TotalSeconds)
            $cv = G 'BCpuVal'; if($cv){ $cv.Text = $v }
            $cb = G 'BCpuBar'; if($cb){ $cb.Value = [math]::Min(100,$v/1000) }
            $script:benchLog += "CPU: ${v} primes/sec  $(Get-Date -f HH:mm)"; UpdateBH
        } catch { $cv = G 'BCpuVal'; if($cv){ $cv.Text = 'ERR' } }
        UnlockBench
    } catch { UnlockBench }
})
(G 'BtnBNet').Add_Click({
    try {
        if ($script:benchRunning) { return }; LockBench
        $nv = G 'BNetVal'; if($nv){ $nv.Text = '...' }
        try {
            $times = @(); 1..5 | ForEach-Object {
                $sw = [System.Diagnostics.Stopwatch]::StartNew()
                try { (New-Object Net.NetworkInformation.Ping).Send('8.8.8.8',1000) | Out-Null } catch {}
                $sw.Stop(); $times += $sw.Elapsed.TotalMilliseconds
            }
            $v = [math]::Round(($times | Measure-Object -Average).Average,1)
            $nv = G 'BNetVal'; if($nv){ $nv.Text = $v }
            $nb = G 'BNetBar'; if($nb){ $nb.Value = [math]::Min(100,[math]::Max(0,100-$v)) }
            $script:benchLog += "NET: ${v}ms  $(Get-Date -f HH:mm)"; UpdateBH
        } catch { $nv = G 'BNetVal'; if($nv){ $nv.Text = 'ERR' } }
        UnlockBench
    } catch { UnlockBench }
})
(G 'BtnBDns').Add_Click({
    try {
        if ($script:benchRunning) { return }; LockBench
        $dv = G 'BDnsVal'; if($dv){ $dv.Text = '...' }
        try {
            $hosts = @('google.com','cloudflare.com','github.com','microsoft.com','youtube.com'); $times = @()
            foreach ($h in $hosts) {
                $sw = [System.Diagnostics.Stopwatch]::StartNew()
                try { [System.Net.Dns]::GetHostEntry($h) | Out-Null } catch {}
                $sw.Stop(); $times += $sw.Elapsed.TotalMilliseconds
            }
            $v = [math]::Round(($times | Measure-Object -Average).Average,1)
            $dv = G 'BDnsVal'; if($dv){ $dv.Text = $v }
            $db = G 'BDnsBar'; if($db){ $db.Value = [math]::Min(100,[math]::Max(0,100-$v)) }
            $script:benchLog += "DNS: ${v}ms avg  $(Get-Date -f HH:mm)"; UpdateBH
        } catch { $dv = G 'BDnsVal'; if($dv){ $dv.Text = 'ERR' } }
        UnlockBench
    } catch { UnlockBench }
})
(G 'BtnBRunAll').Add_Click({
    try {
        if ($script:benchRunning) { return }; LockBench
        AddLog "Running all benchmarks..." '#38BDF8'
        # Disk Write
        try { $t="$env:TEMP\zb.tmp"; $sw=[System.Diagnostics.Stopwatch]::StartNew(); [System.IO.File]::WriteAllBytes($t,(New-Object byte[](52428800))); $sw.Stop(); Remove-Item $t -Force -EA SilentlyContinue; $v=[math]::Round(50/$sw.Elapsed.TotalSeconds); $dv=G 'BDiskVal'; if($dv){$dv.Text=$v}; $db=G 'BDiskBar'; if($db){$db.Value=[math]::Min(100,$v/6)}; $script:benchLog += "DISK WRITE: ${v} MB/s  $(Get-Date -f HH:mm)" } catch {}
        # Disk Read
        try { $t="$env:TEMP\zbr.tmp"; [System.IO.File]::WriteAllBytes($t,(New-Object byte[] 52428800)); $sw=[System.Diagnostics.Stopwatch]::StartNew(); [System.IO.File]::ReadAllBytes($t)|Out-Null; $sw.Stop(); Remove-Item $t -Force -EA SilentlyContinue; $v=[math]::Round(50/$sw.Elapsed.TotalSeconds); $rv=G 'BDiskRVal'; if($rv){$rv.Text=$v}; $rb=G 'BDiskRBar'; if($rb){$rb.Value=[math]::Min(100,$v/6)}; $script:benchLog += "DISK READ: ${v} MB/s  $(Get-Date -f HH:mm)" } catch {}
        # RAM
        try { $ms=New-Object System.IO.MemoryStream 134217728; $buf=New-Object byte[] 1048576; $sw=[System.Diagnostics.Stopwatch]::StartNew(); for($i=0;$i -lt 128;$i++){$ms.Write($buf,0,$buf.Length)}; $sw.Stop(); $ms.Dispose(); $v=[math]::Round(128/$sw.Elapsed.TotalSeconds); $rv=G 'BRamVal'; if($rv){$rv.Text=$v}; $rb=G 'BRamBar'; if($rb){$rb.Value=[math]::Min(100,$v/100)}; $script:benchLog += "RAM: ${v} MB/s  $(Get-Date -f HH:mm)" } catch {}
        # CPU
        try { $sw=[System.Diagnostics.Stopwatch]::StartNew(); $n=0; for($x=2;$x -lt 100000;$x++){$p=$true; for($y=2;$y -le [math]::Sqrt($x);$y++){if($x%$y -eq 0){$p=$false;break}}; if($p){$n++}}; $sw.Stop(); $v=[math]::Round($n/$sw.Elapsed.TotalSeconds); $cv=G 'BCpuVal'; if($cv){$cv.Text=$v}; $cb=G 'BCpuBar'; if($cb){$cb.Value=[math]::Min(100,$v/1000)}; $script:benchLog += "CPU: ${v} primes/sec  $(Get-Date -f HH:mm)" } catch {}
        # DNS
        try { $hosts=@('google.com','cloudflare.com','github.com','microsoft.com','youtube.com'); $times=@(); foreach($h in $hosts){$sw=[System.Diagnostics.Stopwatch]::StartNew(); try{[System.Net.Dns]::GetHostEntry($h)|Out-Null}catch{}; $sw.Stop(); $times+=$sw.Elapsed.TotalMilliseconds}; $v=[math]::Round(($times|Measure-Object -Average).Average,1); $dv=G 'BDnsVal'; if($dv){$dv.Text=$v}; $db=G 'BDnsBar'; if($db){$db.Value=[math]::Min(100,[math]::Max(0,100-$v))}; $script:benchLog += "DNS: ${v}ms avg  $(Get-Date -f HH:mm)" } catch {}
        # NET
        try { $times=@(); 1..5|ForEach-Object{$sw=[System.Diagnostics.Stopwatch]::StartNew(); try{(New-Object Net.NetworkInformation.Ping).Send('8.8.8.8',1000)|Out-Null}catch{}; $sw.Stop(); $times+=$sw.Elapsed.TotalMilliseconds}; $v=[math]::Round(($times|Measure-Object -Average).Average,1); $nv=G 'BNetVal'; if($nv){$nv.Text=$v}; $nb=G 'BNetBar'; if($nb){$nb.Value=[math]::Min(100,[math]::Max(0,100-$v))}; $script:benchLog += "NET: ${v}ms  $(Get-Date -f HH:mm)" } catch {}
        UpdateBH; AddLog "All benchmarks complete." '#22C55E'; UnlockBench
    } catch { UnlockBench }
})

# ── SCRIPT RUNNER ─────────────────────────────────────────────────────────────
(G 'BtnRunScript').Add_Click({
    try {
        $si = G 'ScriptIn'; $so = G 'ScriptOut'; $st = G 'ScriptType'
        if (-not $si) { return }
        $cmd = $si.Text.Trim(); if (-not $cmd) { return }
        $isPS = $st -and $st.SelectedIndex -eq 1
        if ($so) { $so.Text += "$(if($isPS){'PS'}else{'CMD'})> $cmd`n" }
        if ($isPS) {
            try { $o = powershell.exe -NoProfile -ExecutionPolicy Bypass -Command $cmd 2>&1; if($so){ $so.Text += "[OK] $($o -join "`n")`n---`n" } }
            catch { if($so){ $so.Text += "[FAIL] $($_.Exception.Message)`n---`n" } }
        } else {
            $r = RunC $cmd
            if ($so) { $so.Text += "$(if($r.OK){'[OK]'}else{'[FAIL]'}) $($r.Out.Substring(0,[math]::Min(400,$r.Out.Length)))`n---`n" }
        }
    } catch {}
})
(G 'BtnClearScript').Add_Click({
    try { $si=G 'ScriptIn'; $so=G 'ScriptOut'; if($si){$si.Text=''}; if($so){$so.Text=''} } catch {}
})

# ── PERSONALIZE ───────────────────────────────────────────────────────────────
$script:wallpaperPending = ''

# Toggle buttons -- all driven by Tag property, single handler loop
$personalizeIds = @(
    'DarkMode','Transparency','ClassicAltTab','NoLoginBlur','OldContextMenu','NoRoundCorners',
    'AeroPeek','AeroTitlebar','AeroGlass','AeroAnimations','AeroSnapAssist','AeroDragFull',
    'SmallIcons','HideSearch','HideWidgets','HideTaskView','CompactMode',
    'ClearType'
)
foreach ($toggleId in $personalizeIds) {
    $btn = G "PBtn_$toggleId"
    if ($btn) {
        $btn.Add_Click({
            param($s,$e)
            try {
                $id       = $s.Tag
                $current  = Get-PersonalizeState $id
                $newState = -not $current
                AddLog "Personalize: $id -> $(if($newState){'ON'}else{'OFF'})" '#38BDF8'
                $ok = Set-PersonalizeTweak $id $newState
                if ($ok) { AddLog "  OK" '#22C55E' } else { AddLog "  FAILED" '#E01818' }
                RefreshPersonalize
            } catch {}
        })
    }
}

# Accent color swatch panel -- single bubbled handler
$accentPanel = G 'PAccentPanel'
if ($accentPanel) {
    $accentPanel.AddHandler(
        [System.Windows.Controls.Button]::ClickEvent,
        [System.Windows.RoutedEventHandler]{
            param($s,$e)
            $hex = $e.OriginalSource.Tag
            if ($hex -and $hex.StartsWith('#')) {
                Set-AccentColor $hex
                # Also enable accent on titlebars automatically
                Set-PersonalizeTweak 'AeroTitlebar' $true | Out-Null
                RefreshPersonalize
            }
        }
    )
}

(G 'PBtnRefresh').Add_Click({ try { RefreshPersonalize } catch {} })

(G 'PBtnRestartExplorer').Add_Click({
    try {
        AddLog "Restarting Explorer for taskbar changes..." '#888888'
        RunC 'taskkill /f /im explorer.exe' | Out-Null
        Start-Sleep -Milliseconds 800
        Start-Process explorer.exe
        AddLog "Explorer restarted. Taskbar changes applied." '#22C55E'
        Start-Sleep -Milliseconds 500
        RefreshPersonalize
    } catch { AddLog "Explorer restart error: $($_.Exception.Message)" '#E01818' }
})

# Color & Display shortcut buttons
(G 'PBtnColorMgmt').Add_Click({
    try { Start-Process 'colorcpl.exe'; AddLog "Opened Color Management." '#F59E0B' } catch {}
})
(G 'PBtnCalibration').Add_Click({
    try { Start-Process 'dccw.exe'; AddLog "Opened Display Calibration Wizard." '#F59E0B' } catch {}
})
(G 'PBtnClearTypeTune').Add_Click({
    try { Start-Process 'cttune.exe'; AddLog "Opened ClearType Tuner." '#F59E0B' } catch {}
})
(G 'PBtnNightLight').Add_Click({
    try { Start-Process 'ms-settings:nightlight'; AddLog "Opened Night Light settings." '#F59E0B' } catch {}
})

# Wallpaper
(G 'PBtnWallpaperPick').Add_Click({
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Image files (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp|All files (*.*)|*.*"
        $dlg.Title  = "Select Wallpaper"
        if ($dlg.ShowDialog() -eq 'OK') {
            $script:wallpaperPending = $dlg.FileName
            $wl = G 'PWallpaperPath'; if($wl){ $wl.Text = $dlg.FileName }
            AddLog "Wallpaper selected: $($dlg.FileName)" '#38BDF8'
        }
    } catch {}
})
(G 'PBtnWallpaperApply').Add_Click({
    try {
        if (-not $script:wallpaperPending) { AddLog "No wallpaper selected. Use BROWSE first." '#F59E0B'; return }
        $path = $script:wallpaperPending
        RunC "reg add `"HKCU\Control Panel\Desktop`" /v Wallpaper      /t REG_SZ /d `"$path`" /f" | Out-Null
        RunC "reg add `"HKCU\Control Panel\Desktop`" /v WallpaperStyle /t REG_SZ /d 10       /f" | Out-Null
        RunC 'rundll32.exe user32.dll,UpdatePerUserSystemParameters' | Out-Null
        AddLog "Wallpaper applied: $path" '#22C55E'
        $script:wallpaperPending = ''
        RefreshPersonalize
    } catch { AddLog "Wallpaper error: $($_.Exception.Message)" '#E01818' }
})


# ── DRIVERS PAGE ──────────────────────────────────────────────────────────────
(G 'BtnDriverRefresh').Add_Click({ try { RefreshDrivers } catch {} })

$drFilter = G 'DrFilter'
if ($drFilter) {
    $drFilter.Add_TextChanged({ try { RefreshDrivers } catch {} })
}

(G 'BtnDriverExport').Add_Click({
    try {
        $drivers = Get-DriverList
        $ts   = Get-Date -Format 'yyyyMMdd_HHmmss'
        $file = Join-Path $script:LOGS "drivers_$ts.csv"
        $drivers | Select-Object Cat, Name, Version, Date, Mfg |
            Export-Csv -Path $file -NoTypeInformation -Encoding UTF8
        AddLog "Drivers exported to: $file" '#22C55E'
    } catch { AddLog "Export error: $($_.Exception.Message)" '#E01818' }
})

# ── GPU HEALTH PAGE ───────────────────────────────────────────────────────────
(G 'BtnGpuRefresh').Add_Click({ try { RefreshGpuHealth } catch {} })

(G 'BtnOpenNvidiaSmi').Add_Click({
    try {
        $paths = @(
            'C:\Windows\System32\nvidia-smi.exe',
            'C:\Program Files\NVIDIA Corporation\NVSMI\nvidia-smi.exe'
        )
        $found = $paths | Where-Object { Test-Path $_ } | Select-Object -First 1
        if ($found) {
            Start-Process 'cmd.exe' "/k `"$found`""
            AddLog "Opened nvidia-smi." '#22C55E'
        } else {
            AddLog "nvidia-smi not found. Install NVIDIA drivers." '#F59E0B'
        }
    } catch {}
})

(G 'BtnOpenGpuZ').Add_Click({
    try {
        $gpuz = Get-Command 'GPU-Z.exe' -EA SilentlyContinue
        if ($gpuz) { Start-Process $gpuz.Source }
        else { AddLog "GPU-Z not found. Install it from App Installer." '#F59E0B' }
    } catch {}
})

# ── LATENCY PAGE ──────────────────────────────────────────────────────────────
(G 'BtnRunLatency').Add_Click({
    try {
        $btn = G 'BtnRunLatency'
        if ($btn) { $btn.IsEnabled = $false }
        $script:Win.Dispatcher.BeginInvoke([action]{
            Run-LatencyCheck
            $b = G 'BtnRunLatency'; if ($b) { $b.IsEnabled = $true }
        })
    } catch {}
})

(G 'BtnLatCopyLog').Add_Click({
    try {
        $lr = G 'LatResults'
        if ($lr -and $lr.Text) {
            [System.Windows.Clipboard]::SetText($lr.Text)
            AddLog "Latency results copied to clipboard." '#22C55E'
        }
    } catch {}
})

(G 'BtnLatSaveLog').Add_Click({
    try {
        $lr = G 'LatResults'
        if ($lr -and $lr.Text) {
            $ts   = Get-Date -Format 'yyyyMMdd_HHmmss'
            $file = Join-Path $script:LOGS "latency_$ts.txt"
            Set-Content -Path $file -Value $lr.Text -Encoding UTF8
            AddLog "Latency results saved to: $file" '#22C55E'
        }
    } catch {}
})

# ── TIMER ─────────────────────────────────────────────────────────────────────
# Cache OS object - only refresh every 3 ticks to reduce WMI overhead
$script:timerTick = 0
$script:cachedOS  = $null
$script:timer = New-Object System.Windows.Threading.DispatcherTimer
$script:timer.Interval = [TimeSpan]::FromSeconds(4)
$script:timer.Add_Tick({
    try {
        $script:timerTick++
        # Refresh OS cache every 3 ticks (~12 seconds) to cut WMI load
        if ($script:timerTick % 3 -eq 0 -or -not $script:cachedOS) {
            $script:cachedOS = Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue
        }
        $cpu  = Get-CimInstance Win32_Processor -EA SilentlyContinue | Select-Object -First 1
        $ci   = if ($cpu) { [int]$cpu.LoadPercentage } else { 0 }
        $os   = $script:cachedOS
        $used = if ($os) { [math]::Round(($os.TotalVisibleMemorySize-$os.FreePhysicalMemory)/1MB,1) } else { 0 }
        $tot  = if ($os) { [math]::Round($os.TotalVisibleMemorySize/1MB,1) } else { 1 }
        $rp   = if ($tot -gt 0) { [math]::Round($used/$tot*100) } else { 0 }
        $cl = G 'CpuLbl'; if($cl){ $cl.Text = "CPU  $ci%" }
        $cb = G 'CpuBar'; if($cb){ $cb.Value = $ci }
        $rl = G 'RamLbl'; if($rl){ $rl.Text = "RAM  ${used}GB" }
        $rb = G 'RamBar'; if($rb){ $rb.Value = $rp }
    } catch {}
})
$script:timer.Start()
