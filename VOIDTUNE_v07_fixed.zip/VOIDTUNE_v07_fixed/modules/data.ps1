# VOIDTUNE - modules/data.ps1
# Copyright (C) 2026 @OTZPT - GPL v3
# All data definitions: tweaks, apps, services, privacy

# ── TWEAKS ────────────────────────────────────────────────────────────────────
$script:TWEAKS = @(
    # CPU
    [TI]@{Id='cpu1';Cat='cpu';Badge='SAFE';BC='#22C55E';Name='HIGH PERF PLAN';Desc='Set power scheme to high performance';Cmd='powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c';RevertCmd='powercfg -setactive 381b4222-f694-41f0-9685-ff5bb260df2e'},
    [TI]@{Id='cpu2';Cat='cpu';Badge='SAFE';BC='#22C55E';Name='WIN32 PRIORITY';Desc='Foreground app gets max CPU slices';Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 38 /f';RevertCmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 2 /f'},
    [TI]@{Id='cpu3';Cat='cpu';Badge='SAFE';BC='#22C55E';Name='TIMER RESOLUTION';Desc='High-precision system timer';Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f';RevertCmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel" /v GlobalTimerResolutionRequests /t REG_DWORD /d 0 /f'},
    [TI]@{Id='cpu4';Cat='cpu';Badge='SAFE';BC='#22C55E';Name='PERF BOOST MODE';Desc='Max processor turbo boost';Cmd='powercfg -setacvalueindex scheme_current sub_processor PERFBOOSTMODE 2 && powercfg -setactive scheme_current';RevertCmd='powercfg -setacvalueindex scheme_current sub_processor PERFBOOSTMODE 1 && powercfg -setactive scheme_current'},
    [TI]@{Id='cpu5';Cat='cpu';Badge='EXTREME';BC='#7c3aed';Name='ULTIMATE PERF';Desc='Hidden ultra performance plan';Cmd='powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61';RevertCmd='powercfg -setactive 381b4222-f694-41f0-9685-ff5bb260df2e'},
    [TI]@{Id='cpu6';Cat='cpu';Badge='EXTREME';BC='#7c3aed';Name='FORCE ALL CORES';Desc='Disable core parking';Cmd='powercfg -setacvalueindex 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 54533251-82be-4824-96c1-47b60b740d00 0cc5b647-c1df-4637-891a-dec35c318583 100 & powercfg -setacvalueindex 381b4222-f694-41f0-9685-ff5bb260df2e 54533251-82be-4824-96c1-47b60b740d00 0cc5b647-c1df-4637-891a-dec35c318583 100 & powercfg -setactive scheme_current & exit /b 0';RevertCmd='powercfg -setacvalueindex 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 54533251-82be-4824-96c1-47b60b740d00 0cc5b647-c1df-4637-891a-dec35c318583 0 & powercfg -setacvalueindex 381b4222-f694-41f0-9685-ff5bb260df2e 54533251-82be-4824-96c1-47b60b740d00 0cc5b647-c1df-4637-891a-dec35c318583 0 & powercfg -setactive scheme_current & exit /b 0'},
    [TI]@{Id='cpu7';Cat='cpu';Badge='EXTREME';BC='#7c3aed';Name='NO PWR THROTTLE';Desc='Remove background CPU limits';Cmd='reg add "HKLM\SOFTWARE\Policies\Microsoft\Power\PowerThrottling" /v PowerThrottlingOff /t REG_DWORD /d 1 /f';RevertCmd='reg delete "HKLM\SOFTWARE\Policies\Microsoft\Power\PowerThrottling" /v PowerThrottlingOff /f'},
    # GPU
    [TI]@{Id='gpu1';Cat='gpu';Badge='SAFE';BC='#22C55E';Name='HW GPU SCHEDULING';Desc='Hardware-accelerated GPU scheduling';Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f';RevertCmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 1 /f'},
    [TI]@{Id='gpu2';Cat='gpu';Badge='SAFE';BC='#22C55E';Name='GPU PRIORITY';Desc='Priority 8 for games';Cmd='reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /t REG_DWORD /d 8 /f';RevertCmd='reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /t REG_DWORD /d 1 /f'},
    [TI]@{Id='gpu3';Cat='gpu';Badge='SAFE';BC='#22C55E';Name='TDR DELAY';Desc='Prevent GPU timeout crashes';Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v TdrDelay /t REG_DWORD /d 10 /f';RevertCmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v TdrDelay /t REG_DWORD /d 2 /f'},
    [TI]@{Id='gpu4';Cat='gpu';Badge='SAFE';BC='#22C55E';Name='DIRECT FLIP';Desc='Reduce display latency';Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v ForceDirectFlip /t REG_DWORD /d 1 /f';RevertCmd='reg delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v ForceDirectFlip /f'},
    [TI]@{Id='gpu5';Cat='gpu';Badge='EXTREME';BC='#7c3aed';Name='DISABLE MPO';Desc='Fix MPO stutters. May cause flickering on some GPUs - revertible';Cmd='reg add "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v OverlayTestMode /t REG_DWORD /d 5 /f';RevertCmd='reg delete "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v OverlayTestMode /f'},
    # RAM
    [TI]@{Id='ram1';Cat='ram';Badge='SAFE';BC='#22C55E';Name='DISABLE PAGING';Desc='Keep kernel in RAM';Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v DisablePagingExecutive /t REG_DWORD /d 1 /f';RevertCmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v DisablePagingExecutive /t REG_DWORD /d 0 /f'},
    [TI]@{Id='ram2';Cat='ram';Badge='SAFE';BC='#22C55E';Name='LARGE SYS CACHE';Desc='Increase RAM cache';Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v LargeSystemCache /t REG_DWORD /d 1 /f';RevertCmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v LargeSystemCache /t REG_DWORD /d 0 /f'},
    [TI]@{Id='ram3';Cat='ram';Badge='SAFE';BC='#22C55E';Name='CLEAR TEMP';Desc='Flush temp files and DNS';Cmd='del /q /f /s "%TEMP%\*" 2>nul & ipconfig /flushdns';RevertCmd=''},
    [TI]@{Id='ram4';Cat='ram';Badge='EXTREME';BC='#7c3aed';Name='NO MEM COMPRESS';Desc='Remove compression overhead';Cmd='PS:Disable-MMAgent -MemoryCompression';RevertCmd='PS:Enable-MMAgent -MemoryCompression'},
    # Network
    [TI]@{Id='net1';Cat='net';Badge='SAFE';BC='#22C55E';Name='DISABLE NAGLES';Desc='TCPNoDelay lower latency';Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v TCPNoDelay /t REG_DWORD /d 1 /f';RevertCmd='reg delete "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v TCPNoDelay /f'},
    [TI]@{Id='net2';Cat='net';Badge='SAFE';BC='#22C55E';Name='TCP FAST OPEN';Desc='Reduce handshake latency';Cmd='netsh int tcp set global fastopen=enabled';RevertCmd='netsh int tcp set global fastopen=disabled'},
    [TI]@{Id='net3';Cat='net';Badge='SAFE';BC='#22C55E';Name='ENABLE RSS';Desc='Multi-core receive scaling';Cmd='netsh int tcp set global rss=enabled';RevertCmd='netsh int tcp set global rss=disabled'},
    [TI]@{Id='net4';Cat='net';Badge='SAFE';BC='#22C55E';Name='FLUSH DNS';Desc='Clear stale DNS cache';Cmd='ipconfig /flushdns';RevertCmd=''},
    [TI]@{Id='net5';Cat='net';Badge='EXTREME';BC='#7c3aed';Name='NO NET THROTTLE';Desc='Remove QoS bandwidth limits';Cmd='reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v NetworkThrottlingIndex /t REG_DWORD /d 4294967295 /f';RevertCmd='reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v NetworkThrottlingIndex /t REG_DWORD /d 10 /f'},
    # Debloat
    [TI]@{Id='deb1';Cat='deb';Badge='SAFE';BC='#22C55E';Name='DISABLE TELEMETRY';Desc='Kill DiagTrack service';Cmd='sc config DiagTrack start= disabled & sc stop DiagTrack & exit /b 0';RevertCmd='sc config DiagTrack start= auto & sc start DiagTrack & exit /b 0'},
    [TI]@{Id='deb2';Cat='deb';Badge='SAFE';BC='#22C55E';Name='BLOCK ADS';Desc='Stop ContentDelivery ads';Cmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v ContentDeliveryAllowed /t REG_DWORD /d 0 /f';RevertCmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v ContentDeliveryAllowed /t REG_DWORD /d 1 /f'},
    [TI]@{Id='deb3';Cat='deb';Badge='SAFE';BC='#22C55E';Name='DISABLE CORTANA';Desc='Remove Cortana and Bing search';Cmd='reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v AllowCortana /t REG_DWORD /d 0 /f';RevertCmd='reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v AllowCortana /f'},
    [TI]@{Id='deb4';Cat='deb';Badge='SAFE';BC='#22C55E';Name='DISABLE GAME BAR';Desc='Remove Xbox Game Bar overhead';Cmd='reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f';RevertCmd='reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 1 /f'},
    [TI]@{Id='deb5';Cat='deb';Badge='SAFE';BC='#22C55E';Name='DISABLE ANIM';Desc='Disable all visual effects';Cmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 2 /f';RevertCmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 0 /f'},
    [TI]@{Id='deb6';Cat='deb';Badge='SAFE';BC='#22C55E';Name='RAW MOUSE';Desc='Disable pointer acceleration';Cmd='reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d 0 /f';RevertCmd='reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d 1 /f'},
    [TI]@{Id='deb7';Cat='deb';Badge='EXTREME';BC='#7c3aed';Name='DISABLE SUPERFETCH';Desc='Stop SysMain preloading';Cmd='sc config SysMain start= disabled & sc stop SysMain & exit /b 0';RevertCmd='sc config SysMain start= auto & sc start SysMain & exit /b 0'},
    [TI]@{Id='deb8';Cat='deb';Badge='SAFE';BC='#22C55E';Name='DISABLE AERO PEEK';Desc='Remove hover-to-peek desktop effect';Cmd='reg add "HKCU\Software\Microsoft\Windows\DWM" /v EnableAeroPeek /t REG_DWORD /d 0 /f';RevertCmd='reg add "HKCU\Software\Microsoft\Windows\DWM" /v EnableAeroPeek /t REG_DWORD /d 1 /f'},
    [TI]@{Id='deb9';Cat='deb';Badge='SAFE';BC='#22C55E';Name='DISABLE AERO SHAKE';Desc='Stop shake-to-minimize all windows';Cmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v DisallowShaking /t REG_DWORD /d 1 /f';RevertCmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v DisallowShaking /t REG_DWORD /d 0 /f'},
    [TI]@{Id='deb10';Cat='deb';Badge='SAFE';BC='#22C55E';Name='DISABLE SNAP ASSIST';Desc='Remove snap layout popup when dragging windows';Cmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v SnapAssist /t REG_DWORD /d 0 /f';RevertCmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v SnapAssist /t REG_DWORD /d 1 /f'},
    [TI]@{Id='deb11';Cat='deb';Badge='SAFE';BC='#22C55E';Name='MENU DELAY 0';Desc='Instant menu open, no hover delay';Cmd='reg add "HKCU\Control Panel\Desktop" /v MenuShowDelay /t REG_SZ /d 0 /f';RevertCmd='reg add "HKCU\Control Panel\Desktop" /v MenuShowDelay /t REG_SZ /d 400 /f'},
    [TI]@{Id='deb12';Cat='deb';Badge='SAFE';BC='#22C55E';Name='NO THUMBNAIL CACHE';Desc='Skip building thumbcache.db on network/temp drives';Cmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v DisableThumbnailCache /t REG_DWORD /d 1 /f';RevertCmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v DisableThumbnailCache /t REG_DWORD /d 0 /f'},
    [TI]@{Id='deb13';Cat='deb';Badge='SAFE';BC='#22C55E';Name='DISABLE STICKINESS';Desc='Turn off sticky/filter/toggle keys popups';Cmd='reg add "HKCU\Control Panel\Accessibility\StickyKeys" /v Flags /t REG_SZ /d 506 /f && reg add "HKCU\Control Panel\Accessibility\ToggleKeys" /v Flags /t REG_SZ /d 58 /f && reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v Flags /t REG_SZ /d 122 /f';RevertCmd='reg add "HKCU\Control Panel\Accessibility\StickyKeys" /v Flags /t REG_SZ /d 510 /f'},
    # Power
    [TI]@{Id='pow1';Cat='pow';Badge='SAFE';BC='#22C55E';Name='BALANCED';Desc='Standard balanced plan';Cmd='powercfg -setactive 381b4222-f694-41f0-9685-ff5bb260df2e';RevertCmd=''},
    [TI]@{Id='pow2';Cat='pow';Badge='SAFE';BC='#22C55E';Name='HIGH PERFORMANCE';Desc='Max clocks no saving';Cmd='powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c';RevertCmd='powercfg -setactive 381b4222-f694-41f0-9685-ff5bb260df2e'},
    [TI]@{Id='pow3';Cat='pow';Badge='EXTREME';BC='#7c3aed';Name='ULTIMATE PERF';Desc='No micro-latency pauses';Cmd='powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61';RevertCmd='powercfg -setactive 381b4222-f694-41f0-9685-ff5bb260df2e'},
    [TI]@{Id='pow4';Cat='pow';Badge='SAFE';BC='#22C55E';Name='DISABLE SLEEP';Desc='No sleep while plugged in';Cmd='powercfg /change standby-timeout-ac 0';RevertCmd='powercfg /change standby-timeout-ac 30'},
    # Latency
    [TI]@{Id='lat1';Cat='lat';Badge='SAFE';BC='#22C55E';Name='FAST APP KILL';Desc='2s app kill timeout';Cmd='reg add "HKCU\Control Panel\Desktop" /v WaitToKillAppTimeout /t REG_SZ /d 2000 /f';RevertCmd='reg add "HKCU\Control Panel\Desktop" /v WaitToKillAppTimeout /t REG_SZ /d 5000 /f'},
    [TI]@{Id='lat2';Cat='lat';Badge='SAFE';BC='#22C55E';Name='FSUTIL OPT';Desc='Optimize NTFS memory usage';Cmd='fsutil behavior set memoryusage 2 && fsutil behavior set disablelastaccess 1';RevertCmd='fsutil behavior set memoryusage 1 && fsutil behavior set disablelastaccess 0'},
    [TI]@{Id='lat3';Cat='lat';Badge='SAFE';BC='#22C55E';Name='IRQ PRIORITY';Desc='Boost IRQ8 interrupt priority. May cause device conflicts on some hardware';Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v IRQ8Priority /t REG_DWORD /d 1 /f';RevertCmd='reg delete "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v IRQ8Priority /f'},
    # Game
    [TI]@{Id='gm1';Cat='game';Badge='SAFE';BC='#22C55E';Name='GAME MODE';Desc='Enable Windows Game Mode';Cmd='reg add "HKCU\Software\Microsoft\GameBar" /v AllowAutoGameMode /t REG_DWORD /d 1 /f';RevertCmd='reg add "HKCU\Software\Microsoft\GameBar" /v AllowAutoGameMode /t REG_DWORD /d 0 /f'},
    [TI]@{Id='gm2';Cat='game';Badge='SAFE';BC='#22C55E';Name='MMCSS HIGH';Desc='High scheduling for games';Cmd='reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d High /f';RevertCmd='reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d Normal /f'},
    [TI]@{Id='gm3';Cat='game';Badge='EXTREME';BC='#7c3aed';Name='NO OVERLAY HOOKS';Desc='Disable FSE overlay hooks';Cmd='reg add "HKCU\System\GameConfigStore" /v GameDVR_FSEBehavior /t REG_DWORD /d 2 /f';RevertCmd='reg delete "HKCU\System\GameConfigStore" /v GameDVR_FSEBehavior /f'},
    [TI]@{Id='gm4';Cat='game';Badge='SAFE';BC='#22C55E';Name='FULLSCREEN OPTIM OFF';Desc='Disable DWM fullscreen optimizations for lower input lag';Cmd='reg add "HKCU\System\GameConfigStore" /v GameDVR_DXGIHonorFSEWindowsCompatible /t REG_DWORD /d 1 /f && reg add "HKCU\System\GameConfigStore" /v GameDVR_FSEBehaviorMode /t REG_DWORD /d 2 /f';RevertCmd='reg delete "HKCU\System\GameConfigStore" /v GameDVR_DXGIHonorFSEWindowsCompatible /f'},
    [TI]@{Id='gm5';Cat='game';Badge='SAFE';BC='#22C55E';Name='DWM FLUSH RATE';Desc='Force DWM to flush every frame, reduces microstutter';Cmd='reg add "HKCU\Software\Microsoft\Windows\DWM" /v Flush /t REG_DWORD /d 1 /f';RevertCmd='reg delete "HKCU\Software\Microsoft\Windows\DWM" /v Flush /f'},
    [TI]@{Id='gm6';Cat='game';Badge='SAFE';BC='#22C55E';Name='CPU PRIORITY GAMES';Desc='Boost game thread priority via MMCSS';Cmd='reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v Priority /t REG_DWORD /d 6 /f && reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "SFIO Priority" /t REG_SZ /d High /f';RevertCmd='reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v Priority /t REG_DWORD /d 2 /f'},
    [TI]@{Id='gm7';Cat='game';Badge='EXTREME';BC='#7c3aed';Name='DISABLE HPET';Desc='Disable High Precision Event Timer - can lower latency on some CPUs';Cmd='bcdedit /set disabledynamictick yes & bcdedit /deletevalue useplatformclock & exit /b 0';RevertCmd='bcdedit /set disabledynamictick no & bcdedit /set useplatformclock true & exit /b 0'},
    # Restore
    [TI]@{Id='rst1';Cat='rst';Badge='RESTORE';BC='#38BDF8';Name='RESTORE NETWORK';Desc='Reset TCP/IP to defaults';Cmd='netsh int tcp set global autotuninglevel=normal';RevertCmd=''},
    [TI]@{Id='rst2';Cat='rst';Badge='RESTORE';BC='#38BDF8';Name='RESTORE POWER';Desc='Back to Balanced plan';Cmd='powercfg -setactive 381b4222-f694-41f0-9685-ff5bb260df2e';RevertCmd=''},
    [TI]@{Id='rst3';Cat='rst';Badge='RESTORE';BC='#38BDF8';Name='RE-ENABLE SVCS';Desc='Restore SysMain and DiagTrack';Cmd='sc config SysMain start= auto & sc start SysMain & sc config DiagTrack start= auto & sc start DiagTrack & exit /b 0';RevertCmd=''},
    [TI]@{Id='rst4';Cat='rst';Badge='RESTORE';BC='#38BDF8';Name='RESTORE VISUAL FX';Desc='Re-enable animations';Cmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 0 /f';RevertCmd=''},
    [TI]@{Id='rst5';Cat='rst';Badge='RESTORE';BC='#38BDF8';Name='RESTORE MOUSE';Desc='Re-enable pointer acceleration';Cmd='reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d 1 /f';RevertCmd=''}
)

# ── ARCHITECTURE TWEAKS (built at runtime after HW detection) ─────────────────
$script:ARCH_TWEAKS = @()

# INTEL CPU
if ($script:HW.CpuVendor -eq 'Intel') {
    $script:ARCH_TWEAKS += [TI]@{
        Id='ix1';Cat='cpu';Badge='SAFE';BC='#22C55E';
        Name='SPEED SHIFT EPP';
        Desc='[INTEL CPU] Enable Speed Shift energy perf preference';
        Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\be337238-0d82-4146-a960-4f3749d470c7" /v ValueMax /t REG_DWORD /d 0 /f';
        RevertCmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\be337238-0d82-4146-a960-4f3749d470c7" /v ValueMax /t REG_DWORD /d 100 /f'
    }

    $script:ARCH_TWEAKS += [TI]@{
        Id='ix2';Cat='cpu';Badge='EXTREME';BC='#7c3aed';
        Name='INTEL DISABLE C-STATES';
        Desc='[INTEL CPU] Prevent deep sleep latency spikes';
        Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Processor" /v Capabilities /t REG_DWORD /d 0x0007e066 /f';
        RevertCmd='reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Processor" /v Capabilities /f'
    }
}

# AMD CPU
if ($script:HW.CpuVendor -eq 'AMD') {
    $script:ARCH_TWEAKS += [TI]@{
        Id='ax1';Cat='cpu';Badge='SAFE';BC='#22C55E';
        Name='AMD CPPC PERF';
        Desc='[AMD CPU] Set Collaborative Processor Performance to max';
        Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v CpuEnergyPerfPref /t REG_DWORD /d 0 /f';
        RevertCmd='reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v CpuEnergyPerfPref /f'
    }

    $script:ARCH_TWEAKS += [TI]@{
        Id='ax2';Cat='cpu';Badge='EXTREME';BC='#7c3aed';
        Name='AMD BOOST MAX';
        Desc='[AMD CPU] Max precision boost via power plan';
        Cmd='powercfg -setacvalueindex scheme_current sub_processor PERFBOOSTPOL 100 && powercfg -setactive scheme_current';
        RevertCmd='powercfg -setacvalueindex scheme_current sub_processor PERFBOOSTPOL 50 && powercfg -setactive scheme_current'
    }

    $script:ARCH_TWEAKS += [TI]@{
        Id='ax3';Cat='cpu';Badge='EXTREME';BC='#7c3aed';
        Name='AMD DISABLE C6';
        Desc='[AMD CPU] Disable C6 core idle to cut latency spikes';
        Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Processor" /v Capabilities /t REG_DWORD /d 0x0007e066 /f';
        RevertCmd='reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Processor" /v Capabilities /f'
    }
}

# NVIDIA GPU
if ($script:HW.GpuVendor -eq 'NVIDIA') {
    $script:ARCH_TWEAKS += [TI]@{
        Id='nx1';Cat='gpu';Badge='SAFE';BC='#22C55E';
        Name='NVIDIA MAX PERF';
        Desc='[NVIDIA GPU] Force prefer max performance power mode';
        Cmd='reg add "HKCU\Software\NVIDIA Corporation\Global\NvCplApi\Policies" /v OverrideAdaptiveThreshold /t REG_DWORD /d 1 /f';
        RevertCmd='reg delete "HKCU\Software\NVIDIA Corporation\Global\NvCplApi\Policies" /v OverrideAdaptiveThreshold /f'
    }

    $script:ARCH_TWEAKS += [TI]@{
        Id='nx2';Cat='gpu';Badge='SAFE';BC='#22C55E';
        Name='NVIDIA NO TELEMETRY';
        Desc='[NVIDIA GPU] Disable NVIDIA telemetry service and reporting';
        Cmd='sc config NvTelemetryContainer start= disabled & sc stop NvTelemetryContainer & reg add "HKLM\SOFTWARE\NVIDIA Corporation\NvControlPanel2\Client" /v OptInOrOutPreference /t REG_DWORD /d 0 /f';
        RevertCmd='sc config NvTelemetryContainer start= auto'
    }

    $script:ARCH_TWEAKS += [TI]@{
        Id='nx3';Cat='gpu';Badge='SAFE';BC='#22C55E';
        Name='NVIDIA SHADER CACHE';
        Desc='[NVIDIA GPU] Ensure shader disk cache is on for faster game loads';
        Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v DisableShaderCache /t REG_DWORD /d 0 /f';
        RevertCmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v DisableShaderCache /t REG_DWORD /d 1 /f'
    }

    $script:ARCH_TWEAKS += [TI]@{
        Id='nx4';Cat='gpu';Badge='EXTREME';BC='#7c3aed';
        Name='NVIDIA HDCP OFF';
        Desc='[NVIDIA GPU] Disable HDCP - small latency gain, non-DRM displays only';
        Cmd='reg add "HKCU\Software\NVIDIA Corporation\Global\NvCplApi\Policies" /v HDCPEnabled /t REG_DWORD /d 0 /f';
        RevertCmd='reg add "HKCU\Software\NVIDIA Corporation\Global\NvCplApi\Policies" /v HDCPEnabled /t REG_DWORD /d 1 /f'
    }
}

# AMD GPU
if ($script:HW.GpuVendor -eq 'AMD') {
    $script:ARCH_TWEAKS += [TI]@{
        Id='agx1';Cat='gpu';Badge='SAFE';BC='#22C55E';
        Name='AMD GPU DEEP SLEEP OFF';
        Desc='[AMD GPU] Disable GPU core deep sleep for lower latency';
        Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000" /v PP_SclkDeepSleepDisable /t REG_DWORD /d 1 /f';
        RevertCmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000" /v PP_SclkDeepSleepDisable /t REG_DWORD /d 0 /f'
    }

    $script:ARCH_TWEAKS += [TI]@{
        Id='agx2';Cat='gpu';Badge='SAFE';BC='#22C55E';
        Name='AMD CHILL OFF';
        Desc='[AMD GPU] Disable Radeon Chill frame limiter';
        Cmd='reg add "HKCU\Software\ATI\ACE\Settings\ADL\CWDDEPM" /v ChillEnabled /t REG_DWORD /d 0 /f';
        RevertCmd='reg add "HKCU\Software\ATI\ACE\Settings\ADL\CWDDEPM" /v ChillEnabled /t REG_DWORD /d 1 /f'
    }

    $script:ARCH_TWEAKS += [TI]@{
        Id='agx3';Cat='gpu';Badge='EXTREME';BC='#7c3aed';
        Name='AMD ULPS OFF';
        Desc='[AMD GPU] Disable Ultra Low Power State - reduces stutter on hybrid systems';
        Cmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000" /v EnableUlps /t REG_DWORD /d 0 /f';
        RevertCmd='reg add "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000" /v EnableUlps /t REG_DWORD /d 1 /f'
    }
}

# LAPTOP
if ($script:HW.IsLaptop) {
    $script:ARCH_TWEAKS += [TI]@{
        Id='lx1';Cat='pow';Badge='SAFE';BC='#22C55E';
        Name='LAPTOP AC PERF';
        Desc='[LAPTOP] Max performance on AC power only';
        Cmd='powercfg -setacvalueindex scheme_current sub_processor PERFBOOSTPOL 100 && powercfg -setactive scheme_current';
        RevertCmd='powercfg -setacvalueindex scheme_current sub_processor PERFBOOSTPOL 50 && powercfg -setactive scheme_current'
    }
}

# ── PRIVACY TWEAKS ────────────────────────────────────────────────────────────
$script:PRIVTWEAKS = @(
    [TI]@{Id='p1';Cat='priv';Badge='SAFE';BC='#22C55E';Name='DISABLE TELEMETRY';Desc='Kill DiagTrack and dmwappushservice';Cmd='sc config DiagTrack start= disabled & sc stop DiagTrack & sc config dmwappushservice start= disabled & sc stop dmwappushservice & exit /b 0'},
    [TI]@{Id='p2';Cat='priv';Badge='SAFE';BC='#22C55E';Name='BLOCK ADS';Desc='Stop Microsoft ad delivery';Cmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v ContentDeliveryAllowed /t REG_DWORD /d 0 /f'},
    [TI]@{Id='p3';Cat='priv';Badge='SAFE';BC='#22C55E';Name='DENY CAMERA';Desc='Block all apps from webcam';Cmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam" /v Value /t REG_SZ /d Deny /f'},
    [TI]@{Id='p4';Cat='priv';Badge='SAFE';BC='#22C55E';Name='DENY MICROPHONE';Desc='Block all apps from mic';Cmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone" /v Value /t REG_SZ /d Deny /f'},
    [TI]@{Id='p5';Cat='priv';Badge='SAFE';BC='#22C55E';Name='DISABLE LOCATION';Desc='Block location access';Cmd='reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" /v Value /t REG_SZ /d Deny /f'},
    [TI]@{Id='p6';Cat='priv';Badge='SAFE';BC='#22C55E';Name='DISABLE CORTANA';Desc='Remove Cortana completely';Cmd='reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v AllowCortana /t REG_DWORD /d 0 /f'},
    [TI]@{Id='p7';Cat='priv';Badge='SAFE';BC='#22C55E';Name='DISABLE ACTIVITY';Desc='Stop timeline tracking';Cmd='reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableActivityFeed /t REG_DWORD /d 0 /f'},
    [TI]@{Id='p8';Cat='priv';Badge='EXTREME';BC='#7c3aed';Name='DISABLE UPDATES';Desc='Stop Windows Update service';Cmd='sc config wuauserv start= disabled && sc stop wuauserv'}
)

# ── APPS ──────────────────────────────────────────────────────────────────────
$script:APPS_DATA = @(
    # Browsers
    [AI]@{Id='Google.Chrome';                  Name='Chrome';              Cat='Browser'},
    [AI]@{Id='Mozilla.Firefox';                Name='Firefox';             Cat='Browser'},
    [AI]@{Id='Brave.Brave';                    Name='Brave';               Cat='Browser'},
    [AI]@{Id='Opera.OperaGX';                  Name='Opera GX';            Cat='Browser'},
    # Communication
    [AI]@{Id='Discord.Discord';                Name='Discord';             Cat='Comm'},
    [AI]@{Id='Telegram.TelegramDesktop';       Name='Telegram';            Cat='Comm'},
    [AI]@{Id='WhatsApp.WhatsApp';              Name='WhatsApp';            Cat='Comm'},
    # Gaming
    [AI]@{Id='Valve.Steam';                    Name='Steam';               Cat='Gaming'},
    [AI]@{Id='EpicGames.EpicGamesLauncher';    Name='Epic Games';          Cat='Gaming'},
    [AI]@{Id='Ubisoft.Connect';                Name='Ubisoft Connect';     Cat='Gaming'},
    [AI]@{Id='ElectronicArts.EADesktop';       Name='EA Desktop';          Cat='Gaming'},
    # Hardware / Monitoring
    [AI]@{Id='TechPowerUp.GPU-Z';              Name='GPU-Z';               Cat='HW Monitor'},
    [AI]@{Id='CPUID.CPU-Z';                    Name='CPU-Z';               Cat='HW Monitor'},
    [AI]@{Id='REALiX.HWiNFO';                 Name='HWiNFO64';            Cat='HW Monitor'},
    [AI]@{Id='MSI.MSIAfterburner';             Name='MSI Afterburner';     Cat='HW Monitor'},
    [AI]@{Id='CrystalDewWorld.CrystalDiskInfo';Name='CrystalDiskInfo';     Cat='HW Monitor'},
    # Tools
    [AI]@{Id='7zip.7zip';                      Name='7-Zip';               Cat='Tools'},
    [AI]@{Id='RARLab.WinRAR';                  Name='WinRAR';              Cat='Tools'},
    [AI]@{Id='VideoLAN.VLC';                   Name='VLC';                 Cat='Tools'},
    [AI]@{Id='OBSProject.OBSStudio';           Name='OBS Studio';          Cat='Tools'},
    [AI]@{Id='Microsoft.PowerToys';            Name='PowerToys';           Cat='Tools'},
    [AI]@{Id='voidtools.Everything';           Name='Everything';          Cat='Tools'},
    [AI]@{Id='HandBrake.HandBrake';            Name='HandBrake';           Cat='Tools'},
    [AI]@{Id='Rufus.Rufus';                    Name='Rufus';               Cat='Tools'},
    [AI]@{Id='ShareX.ShareX';                  Name='ShareX';              Cat='Tools'},
    [AI]@{Id='AutoHotkey.AutoHotkey';          Name='AutoHotkey';          Cat='Tools'},
    [AI]@{Id='JAMSoftware.TreeSize.Free';      Name='TreeSize Free';       Cat='Tools'},
    [AI]@{Id='WinSCP.WinSCP';                  Name='WinSCP';              Cat='Tools'},
    # Media / Creative
    [AI]@{Id='GIMP.GIMP';                      Name='GIMP';                Cat='Media'},
    [AI]@{Id='Audacity.Audacity';              Name='Audacity';            Cat='Media'},
    # Dev
    [AI]@{Id='SublimeHQ.SublimeText.4';        Name='Sublime Text';        Cat='Dev'},
    [AI]@{Id='Microsoft.VisualStudioCode';     Name='VS Code';             Cat='Dev'},
    [AI]@{Id='Notepad++.Notepad++';            Name='Notepad++';           Cat='Dev'},
    [AI]@{Id='Git.Git';                        Name='Git';                 Cat='Dev'},
    [AI]@{Id='GitHub.GitHubDesktop';           Name='GitHub Desktop';      Cat='Dev'},
    [AI]@{Id='OpenJS.NodeJS';                  Name='Node.js';             Cat='Dev'},
    [AI]@{Id='Python.Python.3';                Name='Python 3';            Cat='Dev'},
    [AI]@{Id='Postman.Postman';                Name='Postman';             Cat='Dev'},
    [AI]@{Id='Neovim.Neovim';                  Name='Neovim';              Cat='Dev'},
    [AI]@{Id='Microsoft.WindowsTerminal';      Name='Windows Terminal';    Cat='Dev'},
    [AI]@{Id='TimKosse.FileZilla.Client';      Name='FileZilla';           Cat='Dev'},
    # Security
    [AI]@{Id='Malwarebytes.Malwarebytes';      Name='Malwarebytes';        Cat='Security'},
    [AI]@{Id='Bitwarden.Bitwarden';            Name='Bitwarden';           Cat='Security'},
    [AI]@{Id='KeePass.KeePass';                Name='KeePass';             Cat='Security'},
    [AI]@{Id='Wireshark.Wireshark';            Name='Wireshark';           Cat='Security'},
    # Media
    [AI]@{Id='Spotify.Spotify';                Name='Spotify';             Cat='Media'},
    [AI]@{Id='GIMP.GIMP';                      Name='GIMP';                Cat='Media'},
    [AI]@{Id='Audacity.Audacity';              Name='Audacity';            Cat='Media'},
    [AI]@{Id='Inkscape.Inkscape';              Name='Inkscape';            Cat='Media'},
    [AI]@{Id='BlenderFoundation.Blender';      Name='Blender';             Cat='Media'},
    [AI]@{Id='DaVinciResolve.DaVinciResolve';  Name='DaVinci Resolve';     Cat='Media'},
    [AI]@{Id='KDE.Kdenlive';                   Name='Kdenlive';            Cat='Media'},
    # Gaming extras
    [AI]@{Id='Parsec.Parsec';                  Name='Parsec';              Cat='Gaming'},
    # System / Utils
    [AI]@{Id='Microsoft.PowerShell';           Name='PowerShell 7';        Cat='System'},
    [AI]@{Id='Chocolatey.Chocolatey';          Name='Chocolatey';          Cat='System'},
    [AI]@{Id='CrystalDewWorld.CrystalDiskMark';Name='CrystalDiskMark';     Cat='System'},
    [AI]@{Id='Ventoy.Ventoy';                  Name='Ventoy';              Cat='System'},
    [AI]@{Id='WizTree.WizTree';                Name='WizTree';             Cat='System'},
    [AI]@{Id='Microsoft.Sysinternals.Suite';   Name='Sysinternals Suite';  Cat='System'},
    [AI]@{Id='ProcessHacker.ProcessHacker';    Name='Process Hacker';      Cat='System'},
    [AI]@{Id='Wagnardsoft.DDU';                Name='Display Driver Uninstaller'; Cat='System'},
    [AI]@{Id='lostindark.DriverStoreExplorer'; Name='DriverStoreExplorer'; Cat='System'},
    [AI]@{Id='AntibodySoftware.WizTree';       Name='BCUninstaller';       Cat='System'},
    [AI]@{Id='Geeks3D.FurMark';               Name='FurMark';             Cat='System'},
    [AI]@{Id='CPUID.HWMonitor';                Name='HWMonitor';           Cat='System'},
    [AI]@{Id='Maxon.CinebenchR23';             Name='Cinebench R23';       Cat='System'},
    [AI]@{Id='PuTTY.PuTTY';                    Name='PuTTY';               Cat='System'}
)

# ── SERVICES ──────────────────────────────────────────────────────────────────
# Dependencies map - used by dependency checker in services tab
$script:SVC_DEPS = @{
    'WSearch'          = @()                        # safe to disable
    'SysMain'          = @()                        # safe to disable
    'DiagTrack'        = @()                        # safe to disable
    'dmwappushservice' = @('DiagTrack')             # used by telemetry
    'wuauserv'         = @('BITS','CryptSvc')       # Windows Update depends on these
    'Spooler'          = @()                        # safe if no printer
    'bthserv'          = @()                        # safe if no Bluetooth
    'RemoteRegistry'   = @()                        # safe to disable
    'TabletInputService'=@()                        # safe on desktops
    'Fax'              = @()                        # safe to disable
    'MapsBroker'       = @()                        # safe to disable
    'RetailDemo'       = @()                        # safe to disable
    'WMPNetworkSvc'    = @()                        # safe to disable
    'XboxGip'          = @()                        # safe if no Xbox controller
    'XblAuthManager'   = @('XblGameSave')           # Xbox auth
    'XblGameSave'      = @()                        # safe to disable
    'XboxNetApiSvc'    = @()                        # safe to disable
    'W32Time'          = @()                        # safe to disable offline
}

$script:SVCS_DATA = @(
    # SAFE to disable
    [SI]@{Name='DiagTrack';         Desc='Windows Telemetry — safe to disable'},
    [SI]@{Name='dmwappushservice';  Desc='WAP Push Routing — telemetry relay'},
    [SI]@{Name='SysMain';           Desc='Superfetch — useless on SSD'},
    [SI]@{Name='WSearch';           Desc='Windows Search indexing — kills HDD'},
    [SI]@{Name='Spooler';           Desc='Print Spooler — disable if no printer'},
    [SI]@{Name='RemoteRegistry';    Desc='Remote Registry — security risk'},
    [SI]@{Name='TabletInputService';Desc='Tablet PC Input — irrelevant on desktop'},
    [SI]@{Name='Fax';              Desc='Fax service — nobody uses this'},
    [SI]@{Name='MapsBroker';        Desc='Offline Maps — unused on most PCs'},
    [SI]@{Name='RetailDemo';        Desc='Store Display Mode — only for retail PCs'},
    [SI]@{Name='WMPNetworkSvc';     Desc='Windows Media Player sharing'},
    [SI]@{Name='W32Time';           Desc='Time sync — safe to disable offline'},
    [SI]@{Name='bthserv';           Desc='Bluetooth — disable if no BT devices'},
    # Xbox - all safe to disable if no Xbox
    [SI]@{Name='XboxGip';           Desc='Xbox Game Input Protocol'},
    [SI]@{Name='XblAuthManager';    Desc='Xbox Live Authentication'},
    [SI]@{Name='XblGameSave';       Desc='Xbox Game Save sync'},
    [SI]@{Name='XboxNetApiSvc';     Desc='Xbox Network API'},
    # Careful
    [SI]@{Name='wuauserv';          Desc='Windows Update — disable with caution'}
)

# ── STATE ─────────────────────────────────────────────────────────────────────
$script:applied      = 0
$script:benchLog     = @()
$script:benchRunning = $false
$script:allPages     = @('PgDash','PgTweaks','PgApps','PgServices','PgStartup','PgPrivacy','PgDiag','PgBench','PgProc','PgSafety','PgScript','PgPersonalize','PgDrivers','PgGpuHealth','PgLatency')
$script:catMap       = @{0='cpu';1='gpu';2='ram';3='net';4='deb';5='pow';6='lat';7='game';8='rst'}
